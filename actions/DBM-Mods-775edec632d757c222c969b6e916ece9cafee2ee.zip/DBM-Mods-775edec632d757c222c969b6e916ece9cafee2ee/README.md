# DBM-Mods

Here are some Mods for Discord Bot Maker!
Feel free to use them in your bots. But please, if you want to share this files please share the URL of this GitHub page.
Then everyone can have the latest update!


Make sure to join the DBM MODS DISCORD SERVER. To stay updated and be able to suggest things! https://dbm-network.com/

## Install Mods:
How to install mods:
1. Download this file http://bit.ly/2pJiqv6
2. Open ZIP and open the first (and only) folder
3. Open DBM
4. Click on Project
5. Click on Open Actions Directory
6. Go one folder back, you should be at /steamapps/common/Discord Bot Maker
7. Now copy all files you downloaded out of the zip file
8. Paste them into your folder you opened
9. Please overwrite existing ones

If you don't run your bot with DBM make sure to copy this actions to your bot directory too! Same for hosted bots!
And if you have any more questions: Join the Discord!

Missing actions will appear as "XYZ is not an Action" in your console.